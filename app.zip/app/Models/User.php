<?php

namespace App\Models;

use App\Traits\HasCuid;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class User extends Authenticatable implements MustVerifyEmail
{
      use HasApiTokens, HasCuid, HasFactory, Notifiable;

    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'name', 'cedula', 'email', 'phone', 'password', 'favorites', 'email_verified_at',
        'email_notifications', 'appointment_reminders', 'daily_summary', 'theme_preference',
    ];

    protected $hidden = ['password'];

    protected $casts = [
        'favorites'             => 'array',
        'email_verified_at'     => 'datetime',
        'email_notifications'   => 'boolean',
        'appointment_reminders' => 'boolean',
        'daily_summary'         => 'boolean',
    ];

    public function pets() {
        return $this->hasMany(Pet::class);
    }

    public function appointments() {
        return $this->hasMany(Appointment::class);
    }

    public function messages() {
        return $this->hasMany(AppointmentMessage::class);
    }

    public function doctor() {
        return $this->hasOne(Doctor::class);
    }
}