<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Service;
use App\Models\User;
use App\Models\WalkInAppointment;
use App\Models\WalkInClient;
use App\Models\Schedule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

/**
 * Gestiona citas presenciales (walk-in) para clientes sin cuenta registrada.
 *
 * Reglas de negocio clave:
 * - Búsqueda de cliente: prioriza walk_in_clients sobre usuarios registrados por teléfono.
 * - Asignación de médico: round-robin por carga del día (menor número de citas activas).
 * - Concurrencia: bloqueo atómico con Cache::lock (Redis en prod / driver default en tests)
 *   para evitar doble-booking cuando múltiples recepcionistas crean citas simultáneamente.
 * - Capacidad: se verifica que al menos un médico competente esté libre en el slot antes
 *   de persistir el registro (re-verificación dentro del lock).
 */
class WalkInController extends Controller
{
    /**
     * Lista las últimas 100 citas walk-in ordenadas por fecha y hora descendente.
     * Incluye relaciones de client, service y doctor para poblar la vista de recepción.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $walkins = WalkInAppointment::with(['client', 'service', 'doctor'])
            ->orderByDesc('date')
            ->orderByDesc('start_time')
            ->limit(100)
            ->get()
            ->map(fn ($w) => $this->formatWalkIn($w));

        return response()->json(['success' => true, 'data' => $walkins]);
    }

    /**
     * Busca un cliente existente por número de teléfono para pre-rellenar el formulario.
     * Sanitiza y valida el formato venezolano (+58 o 58 + 9 dígitos). La búsqueda
     * prioriza walk_in_clients (frecuentes presenciales) y cae alç tabla de usuarios
     * registrados si no hay coincidencia, minimizando la carga de datos al frontend.
     *
     * @return \Illuminate\Http\JsonResponse  null en data si no se encuentra ningún cliente.
     */
    public function search(Request $request)
    {
        $phone = $request->query('phone');

        // Sanitización para dejar solo números y +
        $phone = preg_replace('/[^0-9+]/', '', $phone);

        // Validar el formato exacto de teléfono venezolano (+58 o 58 seguido de 9 dígitos)
        if (!$phone || !preg_match('/^\+?58\d{9}$/', $phone)) {
            return response()->json(['success' => true, 'data' => null]);
        }

        // Primero buscar en walk_in_clients (clientes presenciales frecuentes) usando búsqueda por prefijo para aprovechar índices
        $walkIn = WalkInClient::where('phone', 'like', "{$phone}%")->limit(5)->get();
        if ($walkIn->isNotEmpty()) {
            $w = $walkIn->first();
            return response()->json([
                'success' => true,
                'data'    => [
                    'type'      => 'walk_in',
                    'ownerName' => $w->owner_name,
                    'phone'     => $w->phone,
                    'email'     => $w->email,
                    'petName'   => $w->pet_name,
                    'petSpecies'=> $w->pet_species,
                    'petBreed'  => $w->pet_breed,
                ],
            ]);
        }

        // Luego buscar en usuarios registrados usando búsqueda por prefijo para aprovechar índices
        $user = User::where('phone', 'like', "{$phone}%")
            ->where('role', 'client')
            ->limit(5)
            ->get();

        if ($user->isNotEmpty()) {
            $u = $user->first();
            return response()->json([
                'success' => true,
                'data'    => [
                    'type'      => 'user',
                    'ownerName' => $u->name,
                    'phone'     => $u->phone,
                    'email'     => $u->email,
                    'petName'   => null,
                    'petSpecies'=> null,
                    'petBreed'  => null,
                ],
            ]);
        }

        return response()->json(['success' => true, 'data' => null]);
    }

    /**
     * Crea una nueva cita walk-in para hoy.
     *
     * Flujo:
     * 1. Valida el payload y calcula end_time a partir del start_time + duration del servicio.
     * 2. Verifica que el horario pedido cae dentro del horario laboral del día (Schedule o
     *    fallback L-V 09:00-18:00).
     * 3. Adquiere un lock atómico por slot para serializar peticiones concurrentes.
     * 4. Dentro del lock, re-verifica capacidad de médicos libres y asigna por round-robin.
     * 5. Persiste WalkInClient (upsert por teléfono) y WalkInAppointment en una transacción.
     *
     * @return \Illuminate\Http\JsonResponse  HTTP 201 con la cita creada, 409 si sin capacidad.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'ownerName'     => 'required|string|max:255',
            'phone'         => 'nullable|string|max:30',
            'email'         => 'nullable|email|max:255',
            'petName'       => 'required|string|max:255',
            'petSpecies'    => 'required|string|max:100',
            'petBreed'      => 'nullable|string|max:100',
            'petBirthDate'  => 'nullable|date|before:today',
            'petWeight'     => 'nullable|numeric|min:0.01|max:150',
            'serviceId'     => 'required|string|exists:services,id',
            'startTime'     => 'required|date_format:H:i',
            'paymentMethod' => 'nullable|string|in:cash,transfer,card,pago_movil',
        ]);

        $service = Service::findOrFail($data['serviceId']);
        $today   = Carbon::today()->format('Y-m-d');

        [$sh, $sm] = explode(':', $data['startTime']);
        $startMinutes = (int)$sh * 60 + (int)$sm;
        $endMinutes   = $startMinutes + $service->duration_minutes;
        $endTime      = sprintf('%02d:%02d', intdiv($endMinutes, 60), $endMinutes % 60);

        // Verificar horario laboral
        $dayOfWeek = Carbon::parse($today)->dayOfWeek;
        $schedule  = Schedule::where('day_of_week', $dayOfWeek)->first();

        // Sin horario guardado, aplicar el predeterminado L-V 09:00-18:00.
        if (!$schedule) {
            $isWeekday = $dayOfWeek >= 1 && $dayOfWeek <= 5;
            if (!$isWeekday) {
                return response()->json(['success' => false, 'error' => 'No hay atención este día'], 400);
            }
            $schedule = (object)[
                'is_available' => true,
                'open_time'    => '09:00',
                'close_time'   => '18:00',
            ];
        }

        if (!$schedule->is_available) {
            return response()->json(['success' => false, 'error' => 'No hay horario disponible para este día'], 400);
        }

        [$oh, $om] = explode(':', $schedule->open_time);
        $openMinutes = (int)$oh * 60 + (int)$om;
        
        [$ch, $cm] = explode(':', $schedule->close_time);
        $closeMinutes = (int)$ch * 60 + (int)$cm;

        if ($startMinutes < $openMinutes || $endMinutes > $closeMinutes) {
            return response()->json([
                'success' => false,
                'error'   => "El horario solicitado está fuera del horario de atención ({$schedule->open_time} – {$schedule->close_time})"
            ], 400);
        }

        $lockKey = "appointment_lock_{$today}_{$data['startTime']}";

        // En producción usamos Redis para locks si está disponible (REDIS_HOST no es nulo en configuración y el driver está cargado).
        // Si no, cae en el driver de cache configurado por defecto (database o array en tests).
        // Esto reduce significativamente la latencia de base de datos para bookings concurrentes.
        $lockStore = (config('database.redis.default.host') && extension_loaded('redis') && !app()->environment('testing')) ? 'redis' : null;
        $lock = $lockStore ? Cache::store($lockStore)->lock($lockKey, 10) : Cache::lock($lockKey, 10);

        try {
            $lock->block(5);

            $slotStart = $data['startTime'];
            $slotEnd   = $endTime;

            // Re-verificar capacidad dentro del bloqueo
            $doctorIds = DB::table('doctor_services')
                ->join('doctors', 'doctors.id', '=', 'doctor_services.doctor_id')
                ->where('doctor_services.service_id', $data['serviceId'])
                ->where('doctors.is_active', true)
                ->pluck('doctor_services.doctor_id');

            $totalDoctors    = $doctorIds->count();
            $usesDoctorLogic = $totalDoctors > 0;

            if ($usesDoctorLogic) {
                $busyFromAppts = Appointment::where('date', $today)
                    ->whereIn('status', ['pending', 'confirmed'])
                    ->whereIn('doctor_id', $doctorIds)
                    ->where('start_time', '<', $slotEnd)
                    ->where('end_time', '>', $slotStart)
                    ->distinct('doctor_id')
                    ->count('doctor_id');

                $busyFromWalkIns = WalkInAppointment::where('date', $today)
                    ->whereIn('status', ['pending', 'confirmed'])
                    ->whereIn('doctor_id', $doctorIds)
                    ->where('start_time', '<', $slotEnd)
                    ->where('end_time', '>', $slotStart)
                    ->distinct('doctor_id')
                    ->count('doctor_id');

                if (($busyFromAppts + $busyFromWalkIns) >= $totalDoctors) {
                    return response()->json(['success' => false, 'error' => 'Ya no hay médicos disponibles en ese horario.'], 409);
                }

                $assignedDoctorId = Doctor::whereHas('services', fn ($q) => $q->where('services.id', $data['serviceId']))
                    ->where('is_active', true)
                    ->withCount(['appointments as today_count' => fn ($q) => $q
                        ->where('date', $today)
                        ->whereIn('status', ['pending', 'confirmed'])
                    ])
                    ->orderBy('today_count')
                    ->value('id');
            } else {
                $overlap = Appointment::where('date', $today)
                    ->whereIn('status', ['pending', 'confirmed'])
                    ->where('start_time', '<', $slotEnd)
                    ->where('end_time', '>', $slotStart)
                    ->exists();

                if ($overlap) {
                    return response()->json(['success' => false, 'error' => 'El horario seleccionado ya está ocupado.'], 409);
                }
                $assignedDoctorId = null;
            }

            $result = DB::transaction(function () use ($data, $service, $today, $endTime, $assignedDoctorId) {
                $client = WalkInClient::updateOrCreate(
                    ['phone' => $data['phone']],
                    [
                        'owner_name'  => $data['ownerName'],
                        'email'       => $data['email'] ?? null,
                        'pet_name'    => $data['petName'],
                        'pet_species' => $data['petSpecies'],
                        'pet_breed'   => $data['petBreed'] ?? null,
                        'pet_birth_date' => $data['petBirthDate'] ?? null,
                        'pet_weight'  => $data['petWeight'] ?? null,
                    ]
                );

                $walkin = WalkInAppointment::create([
                    'walk_in_client_id' => $client->id,
                    'service_id'        => $data['serviceId'],
                    'doctor_id'         => $assignedDoctorId,
                    'date'              => $today,
                    'start_time'        => $data['startTime'],
                    'end_time'          => $endTime,
                    'status'            => 'confirmed',
                    'payment_method'    => $data['paymentMethod'] ?? null,
                    'payment_status'    => 'pending',
                    'payment_amount'    => $service->price,
                ]);

                return $walkin->load(['client', 'service', 'doctor']);
            });

            return response()->json(['success' => true, 'data' => $this->formatWalkIn($result)], 201);

        } catch (\Illuminate\Contracts\Cache\LockTimeoutException $e) {
            return response()->json(['success' => false, 'error' => 'El sistema está ocupado, por favor reintenta.'], 408);
        } finally {
            $lock?->release();
        }
    }


    /**
     * Registra el pago de una cita walk-in y la marca como completada.
     * Valida método y monto, actualiza payment_status a 'paid' y status a 'completed'
     * de forma atómica, registrando además la fecha/hora de cobro (paid_at).
     *
     * @param  string  $id  ID de la cita walk-in.
     * @return \Illuminate\Http\JsonResponse
     */
    public function confirmPayment(Request $request, $id)
    {
        $walkin = WalkInAppointment::findOrFail($id);

        $data = $request->validate([
            'paymentMethod' => 'required|string|in:cash,transfer,card,pago_movil',
            'paymentAmount' => 'required|numeric|min:0',
        ]);

        $walkin->update([
            'payment_method' => $data['paymentMethod'],
            'payment_amount' => $data['paymentAmount'],
            'payment_status' => 'paid',
            'paid_at'        => now(),
            'status'         => 'completed',
        ]);

        return response()->json(['success' => true, 'data' => $this->formatWalkIn($walkin->fresh(['client', 'service', 'doctor']))]);
    }

    private function formatWalkIn(WalkInAppointment $w): array
    {
        return [
            'id'            => $w->id,
            'date'          => $w->date,
            'startTime'     => $w->start_time,
            'endTime'       => $w->end_time,
            'status'        => $w->status,
            'paymentMethod' => $w->payment_method,
            'paymentStatus' => $w->payment_status,
            'paymentAmount' => $w->payment_amount,
            'paidAt'        => $w->paid_at?->toISOString(),
            'client'        => $w->client ? [
                'ownerName'  => $w->client->owner_name,
                'phone'      => $w->client->phone,
                'petName'    => $w->client->pet_name,
                'petSpecies' => $w->client->pet_species,
            ] : null,
            'service'       => $w->service ? ['id' => $w->service->id, 'name' => $w->service->name, 'price' => $w->service->price] : null,
            'doctor'        => $w->doctor ? ['id' => $w->doctor->id, 'name' => $w->doctor->name] : null,
        ];
    }
}