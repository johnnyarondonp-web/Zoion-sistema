# CHANGELOG — Zoion sistema

Este archivo registra de forma estructurada y cronológica todos los cambios significativos, optimizaciones de rendimiento, parches de seguridad y mejoras en la documentación introducidas en la plataforma **Zoion**.

El proyecto sigue una convención de **Versionamiento Semántico Adaptado**:
*   **Mayor (`V4.0.0`)**: Cambios de gran escala, actualizaciones mayores del framework o rediseños de la arquitectura.
*   **Menor (`V3.9.0`)**: Nuevas funcionalidades mayores, optimizaciones críticas de rendimiento, adición de índices compuestos o capas de servicios.
*   **Parche (`V3.9.1`)**: Correcciones de bugs menores, parches rápidos, y mejoras menores en la documentación o tipografía.

---

## [V3.9.16] - 2026-05-18

### Añadido
- **Recepcionista**: Habilitación completa de la vista "Fechas Bloqueadas" (Excepciones del Calendario) para el rol de recepcionista, removiendo el control `adminOnly` del menú lateral y adaptando la seguridad de las rutas y endpoints de Laravel.
- **Recepcionista**: Incorporación del rol de recepcionista en la recepción de notificaciones generales en tiempo real (nuevas citas, cancelaciones, nuevos mensajes) mediante la optimización de `NotifyAdminsJob`.
- **Notificaciones**: Redirección inteligente y robusta en la campana de notificaciones del frontend basada en el rol del usuario (`isStaff`, `isDoctor`, `isClient`), dirigiendo a la recepcionista a las vistas correctas de administración.

### Corregido
- **Recepcionista**: Autorización completa del rol de recepcionista para confirmar, cancelar o actualizar el estado de citas y realizar el envío y recepción de mensajes de chat en citas, eliminando bloqueos de código 403.
- **Recepcionista**: Corrección en el redireccionamiento del botón "Mi Perfil" en la barra de navegación para usuarios del staff, apuntando a `/admin/profile` en lugar de la ruta de cliente y permitiendo la actualización de claves.
- **Horarios**: Alineación visual responsiva del banner informativo de consejos de gestión (`💡 Consejo de gestión...`) fijando su ancho con `max-w-4xl` para un acabado estético de primer nivel.
- **Base de Datos**: Corrección de incompatibilidad SQL en el gráfico de citas diarias de `DashboardController` convirtiendo el casteo Postgres-specific `date::varchar` en una expresión adaptativa que tolera SQLite de manera transparente en los tests.

---

## [V3.9.10] - 2026-05-17

### Añadido
- **Médico**: Lógica completa para el registro de vacunaciones clínicas desde el detalle del paciente en la Agenda del doctor (`Agenda.tsx`), con un formulario de aplicación interactivo (nombre, fecha, próxima dosis, veterinario y notas/lote) y pre-poblamiento automático del veterinario aplicante.
- **Diseño**: Visualización responsiva y premium de dos columnas en la sección inferior del detalle del paciente, separando claramente el "Historial Clínico" de consultas del nuevo "Registro de Vacunas" para una legibilidad superior.
- **Pruebas**: Suite de pruebas unitarias automatizada `test_doctor_can_register_vaccination_record` en `ZoionBugFixesTest.php` que valida el registro exitoso de vacunaciones por parte del personal clínico y su persistencia correcta en base de datos.

### Corregido
- **Diseño**: Remoción de márgenes grises en las tarjetas de mascotas en `Pets.tsx` empleando `object-cover` para un rellenado fluido edge-to-edge.
- **Diseño**: Simplificación del "Resumen de Salud" en `PetDetail.tsx` a un elegante "Resumen Clínico" con una grilla de 4 columnas, eliminando elementos innecesarios como la barra de progreso, botón de imprimir, dinero gastado y peso/estabilidad.

---

## [V3.9.9] - 2026-05-17

### Añadido
- **Citas**: Restricción técnica de reserva para un máximo de 3 meses en el futuro, tanto en la validación del backend (`StoreAppointmentRequest.php`) como en el control dinámico del calendario en el frontend (`BookingWizard.tsx`).
- **Diseño**: Contenedores verdes HSL altamente estilizados para destacar de forma premium y estética los días disponibles en el calendario de citas, incluyendo una nueva leyenda informativa "Día disponible".
- **Pruebas**: Nueva suite de pruebas automatizadas en `ZoionBugFixesTest.php` para validar el rechazo de reservas con más de 3 meses de anticipación.

### Corregido
- **Autenticación**: Captura robusta de excepciones del mailer SMTP en `EmailVerificationController.php` bajo bloques `try-catch`, y despliegue reactivo de banners de alerta amigables en `VerifyEmail.tsx` para evitar caídas de servidor si las credenciales fallan o expiran.

---

## [V3.9.8] - 2026-05-17

### Corregido
- **Autenticación**: Sincronización robusta de los errores de validación de Inertia en el estado local de React dentro de `Login.tsx`, garantizando que las credenciales incorrectas muestren alertas inmediatas al usuario.
- **Autenticación**: Eliminación del middleware redundante `throttle:5,1` en la ruta `/login`, delegando el control de rate-limiting al controlador para responder con redirecciones de sesión amigables en lugar de páginas de error 429 crudas del navegador.
- **Pruebas**: Refactorización de `test_login_is_throttled` en `RegressionFixTest.php` para validar las redirecciones y mensajes de error específicos del rate limiter en la sesión, logrando la aprobación total de la suite de pruebas.

---

## [V3.9.7] - 2026-05-17

### Corregido
- **Seguridad**: Adición manual de `email_verified_at` con valor `now()` en los Seeders (`AdminUserSeeder`, `DatabaseSeeder`) y en el comando de consola `zoion:admin` para evitar bloqueos de inicio de sesión de perfiles administrativos y de prueba bajo flujos estrictos de verificación de email.

---

## [V3.9.6] - 2026-05-17

### Añadido
- **Seguridad**: Bloqueo estricto contra el bypass de calificación de citas en el endpoint general de actualización (PATCH) para perfiles de cliente, reforzando la idempotencia del rating.
- **Seguridad**: Regeneración y rotación exitosa de la clave de cifrado local `APP_KEY` para invalidar sesiones previas y asegurar la integridad criptográfica del sistema.
- **Pruebas**: Adición del test `test_rating_no_se_puede_sobrescribir_via_update` en `AppointmentFlowsTest.php` para validar la seguridad del PATCH general.

### Optimizado
- **Dashboard**: Refactorización de las consultas mensuales en `DashboardController` (`index()` y `reports()`) agrupando por `DB::raw()` en lugar del alias de select, garantizando compatibilidad nativa con motores SQL estrictos como PostgreSQL.
- **Rendimiento**: Optimización del hook React `usePendingAppointments.ts` filtrando por `status=pending` en el backend (`GET /api/appointments?status=pending&limit=50`), reduciendo drásticamente la carga de datos innecesarios del cliente.

---

## [V3.9.5] - 2026-05-17

### Añadido
- **Pruebas**: Adición del test unitario de cola en `tests/Unit/NotifyAdminsJobTest.php` para asegurar la correcta y única inserción en lote de notificaciones dirigidas a perfiles administrativos.
- **Pruebas**: Consolidación y validación del test de robustez/idempotencia `test_rating_no_se_puede_calificar_dos_veces` en `tests/Feature/AppointmentFlowsTest.php` para evitar dobles solicitudes de calificación en citas completadas.

---

## [V3.9.4] - 2026-05-17

### Añadido
- **API**: Creación de la colección de endpoints en `/docs/Zoion_API.postman_collection.json` conteniendo la estructura completa de rutas públicas, de clientes y de administración.
- **Documentación**: Incorporación de *docblocks* descriptivos a nivel de clase y método en los controladores `DashboardController`, `UploadController` y `WalkInController` para clarificar parámetros, flujos concurrentes, exclusión de N+1 y manejo de almacenamiento.

### Corregido
- **Documentación**: Corrección de discrepancia tecnológica en la tabla del `README.md` actualizando el stack frontend a **React 19** y **TypeScript 6** (en concordancia con las dependencias declaradas en `package.json`).

---

## [V3.9.3] - 2026-05-17

### Documentación
- **Dashboard**: Documentación del fix estratégico para solucionar el loop interno de 20 queries consecutivas en la carga inicial, garantizando que el equipo comprenda la optimización de agregación y el caching.

---

## [V3.9.2] - 2026-05-17

### Corregido
- **Modelos/Traits**: Corrección de la nomenclatura del Trait de ULIDs para estandarizar el nombrado consistente de clases generadoras de llaves en los modelos Eloquent.

---

## [V3.9.1] - 2026-05-17

### Optimizado
- **Procesos en Cola**: Optimización de la ejecución del sistema de Jobs para un procesamiento más ligero y eficiente.
- **Modelos**: Depuración y limpieza de campos redundantes en los modelos principales del sistema para evitar sobrecarga en la hidratación de datos.

---

## [V3.9.0] - 2026-05-16

### Añadido
- **Auditoría**: Culminación exitosa del primer audit completo de documentación técnica e infraestructura de la base de datos.

### Corregido
- **Finanzas**: Corrección en las consultas de cálculo de ingresos mensuales para contemplar estados atómicos de transacciones y estados de pago reales.

---

## [V3.8.9] - 2026-05-16

### Añadido
- **Documentación**: Resolución completa del primer lote de inconsistencias de documentación y alineación de guías de estilo para portafolio.

### Optimizado
- **Dashboard/UI**: Refactorización dinámica del comportamiento responsivo de los gráficos estadísticos del panel administrativo, asegurando visualización nativa y fluida en terminales móviles.

---

## [V3.8.8] - 2026-05-16

### Añadido
- **Pruebas**: Implementación de suites de prueba dedicadas para verificar la robustez de los flujos de autenticación (`auth`), aserciones para la subida segura de imágenes (`uploads`) y comprobación de lógica para impedir el solapamiento concurrente de citas médicas (`doctor availability`).
